import numpy as np
import pandas as pd
from datetime import datetime
from pandas import DataFrame
from typing import Optional

from freqtrade.strategy import (
    IStrategy,
    Trade,
    BooleanParameter,
    CategoricalParameter,
    DecimalParameter,
    IntParameter,
    RealParameter,
    stoploss_from_absolute,
)

import talib.abstract as ta
from technical import qtpylib


class KC_Breakout(IStrategy):

    INTERFACE_VERSION = 3
    can_short: bool = False

    # Hard fallback — real SL is ATR-based via custom_stoploss
    stoploss = -0.10
    trailing_stop = False

    # ROI disabled — TP handled via custom_sell / roi computed at entry
    # Set absurdly high so it never triggers before our fixed TP does
    minimal_roi = {"0": 10.0}

    timeframe = "4h"
    process_only_new_candles = True

    use_exit_signal = False        # exits driven by custom_stoploss + roi only
    exit_profit_only = False
    ignore_roi_if_entry_signal = True

    # 4H × 200 candles ≈ 33 days — enough to cover all rolling windows
    startup_candle_count: int = 200

    # ── Entry parameters ──────────────────────────────────────────────────────

    kc_period = IntParameter(low=10, high=40, default=20, space="buy",
                             optimize=True, load=True)
    kc_mult = RealParameter(low=1.5, high=3.0, default=2.0, space="buy",
                            optimize=True, load=True)

    atr_period = IntParameter(low=7, high=21, default=14, space="buy",
                              optimize=True, load=True)
    atr_sma_period = IntParameter(low=10, high=30, default=20, space="buy",
                                  optimize=True, load=True)

    vol_sma_period = IntParameter(low=10, high=40, default=20, space="buy",
                                  optimize=True, load=True)
    vol_mult = RealParameter(low=1.0, high=2.5, default=1.5, space="buy",
                             optimize=True, load=True)

    adx_period = IntParameter(low=10, high=20, default=14, space="buy",
                              optimize=True, load=True)
    adx_threshold = IntParameter(low=15, high=30, default=20, space="buy",
                                 optimize=True, load=True)

    # ── Exit parameters ───────────────────────────────────────────────────────

    atr_mult_sl = RealParameter(low=1.0, high=2.5, default=1.5, space="sell",
                                optimize=True, load=True)
    rr_ratio = RealParameter(low=2.5, high=5.0, default=3.0, space="sell",
                             optimize=True, load=True)

    # ── Plot config ───────────────────────────────────────────────────────────

    plot_config = {
        "main_plot": {
            "kc_upper": {"color": "#378ADD"},
            "kc_mid":   {"color": "#888780"},
            "kc_lower": {"color": "#378ADD"},
        },
        "subplots": {
            "ATR": {
                "atr":     {"color": "#1D9E75"},
                "atr_sma": {"color": "#E24B4A"},
            },
            "ADX": {
                "adx": {"color": "#D4537E"},
            },
            "Volume": {
                "vol_sma": {"color": "#FAC775"},
            },
        },
    }

    # ── Indicators ────────────────────────────────────────────────────────────

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:

        # Keltner Channel
        kc_period = int(self.kc_period.value)
        kc_mult   = float(self.kc_mult.value)
        atr_period = int(self.atr_period.value)

        dataframe["kc_mid"]   = ta.EMA(dataframe, timeperiod=kc_period)
        dataframe["atr"]      = ta.ATR(dataframe, timeperiod=atr_period)
        dataframe["kc_upper"] = dataframe["kc_mid"] + kc_mult * dataframe["atr"]
        dataframe["kc_lower"] = dataframe["kc_mid"] - kc_mult * dataframe["atr"]

        # ATR expansion filter
        dataframe["atr_sma"]  = dataframe["atr"].rolling(
            int(self.atr_sma_period.value)
        ).mean()

        # Volume filter
        dataframe["vol_sma"]  = dataframe["volume"].rolling(
            int(self.vol_sma_period.value)
        ).mean()

        # ADX
        dataframe["adx"]      = ta.ADX(dataframe, timeperiod=int(self.adx_period.value))

        return dataframe

    # ── Entry ─────────────────────────────────────────────────────────────────

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["enter_long"]  = 0
        dataframe["enter_short"] = 0

        # Condition 1 — Keltner breakout (shift(1) prevents lookahead)
        breakout = (
            (dataframe["close"]   >  dataframe["kc_upper"].shift(1)) &
            (dataframe["close"].shift(1) <= dataframe["kc_upper"].shift(2))
        )

        # Condition 2 — ATR expanding
        atr_expanding = dataframe["atr"] > dataframe["atr_sma"]

        # Condition 3 — Volume spike
        vol_spike = dataframe["volume"] > (
            dataframe["vol_sma"] * float(self.vol_mult.value)
        )

        # Condition 4 — ADX rising and above threshold
        adx_ok = (
            (dataframe["adx"] > int(self.adx_threshold.value)) &
            (dataframe["adx"] > dataframe["adx"].shift(1))
        )

        entry = breakout & atr_expanding & vol_spike & adx_ok

        dataframe.loc[entry, "enter_long"] = 1
        dataframe.loc[entry, "enter_tag"]  = "KC_Breakout"

        return dataframe

    # ── Exit signal (disabled — exits via custom_stoploss + roi) ─────────────

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["exit_long"]  = 0
        dataframe["exit_short"] = 0
        return dataframe

    # ── Custom stoploss — ATR-based absolute price level ─────────────────────

    def custom_stoploss(
        self,
        pair: str,
        trade: Trade,
        current_time: datetime,
        current_rate: float,
        current_profit: float,
        **kwargs,
    ) -> float:
        """
        Places SL at: entry_price - atr_mult_sl × ATR

        Also dynamically sets minimal_roi on the trade object to lock in
        the fixed TP at rr_ratio × SL_distance from entry.
        """
        if not hasattr(self, "dp") or self.dp is None:
            return self.stoploss

        df = self.dp.get_pair_dataframe(pair=pair, timeframe=self.timeframe)
        if df is None or df.empty:
            return self.stoploss

        atr_v = ta.ATR(df, timeperiod=int(self.atr_period.value)).iloc[-1]

        if pd.isna(atr_v) or atr_v == 0.0:
            return self.stoploss

        # Absolute SL price
        sl_price = trade.open_rate - float(self.atr_mult_sl.value) * float(atr_v)

        # Derive TP from R ratio and update minimal_roi dynamically
        sl_dist   = trade.open_rate - sl_price          # positive distance
        tp_price  = trade.open_rate + float(self.rr_ratio.value) * sl_dist
        tp_pct    = (tp_price / trade.open_rate) - 1.0  # as fraction

        # Override the class-level roi with this trade's computed TP
        self.minimal_roi = {"0": round(tp_pct, 6)}

        # Convert absolute SL price to relative ratio for Freqtrade
        desired_sl = stoploss_from_absolute(sl_price, trade.open_rate)

        if desired_sl is None or desired_sl >= 0:
            return self.stoploss

        return desired_sl